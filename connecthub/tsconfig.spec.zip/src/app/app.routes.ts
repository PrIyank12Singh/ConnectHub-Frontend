import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  {
    path: 'login',
    loadComponent: () => import('./features/auth/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'register',
    loadComponent: () => import('./features/auth/register/register.component').then(m => m.RegisterComponent)
  },
  {
    path: 'chat',
    loadComponent: () => import('./features/chat/chat-layout/chat-layout.component').then(m => m.ChatLayoutComponent),
    canActivate: [authGuard]
  },
  {
    path: 'oauth-callback',
    loadComponent: () => import('./features/auth/oauth-callback/oauth-callback.component')
    .then(m => m.OAuthCallbackComponent)
  },
  { path: '**', redirectTo: '/login' }
];