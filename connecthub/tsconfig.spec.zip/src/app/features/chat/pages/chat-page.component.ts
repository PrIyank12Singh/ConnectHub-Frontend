// ═══════════════════════════════════════════════════════════════════════════
// GAP 10 — chat-page.component.ts  PATCH FILE
// File: src/app/features/chat/pages/chat-page.component.ts
//
// Apply each section in order. Every hunk shows the ORIGINAL line(s) to find
// (marked ← FIND) and the REPLACEMENT block (marked ← REPLACE WITH).
// ═══════════════════════════════════════════════════════════════════════════


// ─── HUNK 1: State variable — add pinnedMessage state ────────────────────
//
// ← FIND (after `roomSettingsError = '';`):
//
//   private shouldScrollToBottom = false;
//
// ← REPLACE WITH:
//
  private shouldScrollToBottom = false;

  // ─── GAP 10: Pin / Unpin ──────────────────────────────────────────────────
  /**
   * The message object that is currently pinned in the selected room.
   * Set when a room is selected (loaded from selectedRoom.pinnedMessageId).
   * Cleared when the user unpins or switches rooms.
   */
  pinnedMessage: Message | null = null;
  /** True while a pin/unpin HTTP call is in flight (disables the button). */
  pinningInProgress = false;
  // ─────────────────────────────────────────────────────────────────────────


// ─── HUNK 2: Template — pinned message banner (after chat header </div>) ──
//
// ← FIND (the closing tag of the chat header block, line ~145):
//
//           </div>
//
//           <!-- Messages -->
//           <div class="flex-1 overflow-y-auto p-6 space-y-3" #messagesContainer>
//
// ← REPLACE WITH:
//
          </div>

          <!-- ── GAP 10: Pinned Message Banner ──────────────────────────── -->
          @if (pinnedMessage) {
            <div class="flex items-center gap-2 px-4 py-2 bg-yellow-50 dark:bg-yellow-900/30
                        border-b border-yellow-200 dark:border-yellow-700 text-sm shrink-0">
              <span class="text-yellow-600 dark:text-yellow-400 text-base">📌</span>
              <div class="flex-1 min-w-0">
                <span class="text-xs text-yellow-500 dark:text-yellow-400 font-semibold uppercase tracking-wide mr-2">Pinned</span>
                <span class="text-gray-700 dark:text-gray-200 truncate">
                  {{ pinnedMessage.isDeleted ? '[message deleted]' : pinnedMessage.content }}
                </span>
              </div>
              @if (isCurrentUserRoomAdmin()) {
                <button (click)="handleUnpinMessage()"
                  [disabled]="pinningInProgress"
                  class="ml-auto text-xs text-yellow-600 dark:text-yellow-400 hover:text-red-500 disabled:opacity-50"
                  title="Unpin message">
                  ✕ Unpin
                </button>
              }
            </div>
          }
          <!-- ─────────────────────────────────────────────────────────────── -->

          <!-- Messages -->
          <div class="flex-1 overflow-y-auto p-6 space-y-3" #messagesContainer>


// ─── HUNK 3: Template — Pin button on each message bubble ─────────────────
//
// The three @if blocks for message action buttons currently look like:
//
//   @if (msg.senderId === user?.userId && !msg.isDeleted && msg.type === 'TEXT') {
//     <div class="flex gap-2 px-1 mt-0.5 justify-end">
//       <button (click)="openReactionPicker(msg)" ...>😊</button>
//       <button (click)="startReply(msg)" ...>↩ Reply</button>
//       <button (click)="startEdit(msg)" ...>Edit</button>
//       <button (click)="handleDeleteMessage(msg.messageId)" ...>Delete</button>
//     </div>
//   }
//   @if (msg.senderId === user?.userId && !msg.isDeleted && msg.type !== 'TEXT') {
//     <div class="flex gap-2 px-1 mt-0.5 justify-end">
//       <button (click)="openReactionPicker(msg)" ...>😊</button>
//       <button (click)="startReply(msg)" ...>↩ Reply</button>
//       <button (click)="handleDeleteMessage(msg.messageId)" ...>Delete</button>
//     </div>
//   }
//   @if (msg.senderId !== user?.userId && !msg.isDeleted) {
//     <div class="flex gap-2 px-1 mt-0.5">
//       <button (click)="openReactionPicker(msg)" ...>😊</button>
//       <button (click)="startReply(msg)" ...>↩ Reply</button>
//     </div>
//   }
//
// ← ADD the 📌 pin button inside each block, BEFORE the closing </div>.
//   The pin button is only shown for Room Admins and only when the message
//   is not already the pinned one. Example for the first block:
//
//   @if (msg.senderId === user?.userId && !msg.isDeleted && msg.type === 'TEXT') {
//     <div class="flex gap-2 px-1 mt-0.5 justify-end">
//       <button (click)="openReactionPicker(msg)" class="text-xs text-gray-400 hover:text-yellow-500">😊</button>
//       <button (click)="startReply(msg)" class="text-xs text-gray-400 hover:text-green-500">↩ Reply</button>
//       <button (click)="startEdit(msg)" class="text-xs text-gray-400 hover:text-blue-500">Edit</button>
//       <button (click)="handleDeleteMessage(msg.messageId)" class="text-xs text-gray-400 hover:text-red-500">Delete</button>
//       <!-- GAP 10: Pin button — only visible to Room Admins -->
//       @if (isCurrentUserRoomAdmin() && pinnedMessage?.messageId !== msg.messageId) {
//         <button (click)="handlePinMessage(msg)"
//           [disabled]="pinningInProgress"
//           class="text-xs text-gray-400 hover:text-yellow-600 disabled:opacity-50"
//           title="Pin this message">
//           📌
//         </button>
//       }
//     </div>
//   }
//
// Apply the same @if block to the other two action blocks (msg.type !== 'TEXT' and msg.senderId !== user?.userId).


// ─── HUNK 4: Component class — getter for admin check ────────────────────
//
// ← FIND (just before the `loadRoomMembers(): void` method, around line 902):
//
//   loadRoomMembers(): void {
//
// ← REPLACE WITH:
//
  // ─── GAP 10: Pin / Unpin helpers ─────────────────────────────────────────

  /**
   * Returns true when the logged-in user is an ADMIN member of the selected room.
   * Used to conditionally render the 📌 Pin button and the ✕ Unpin button.
   */
  isCurrentUserRoomAdmin(): boolean {
    if (!this.user || !this.roomMembers.length) return false;
    const me = this.roomMembers.find(m => m.userId === this.user.userId);
    return me?.role === 'ADMIN';
  }

  /**
   * Pin a message. Calls POST /web/room-manager/rooms/{roomId}/pin/{messageId}
   * via RoomService, then updates the local pinnedMessage reference.
   */
  handlePinMessage(msg: Message): void {
    if (!this.selectedRoom || !this.user || this.pinningInProgress) return;
    this.pinningInProgress = true;
    this.roomService.pinMessage(this.selectedRoom.roomId, msg.messageId).subscribe({
      next: (updatedRoom) => {
        // Refresh the selectedRoom so pinnedMessageId is up-to-date
        this.selectedRoom = { ...this.selectedRoom!, pinnedMessageId: updatedRoom.pinnedMessageId };
        this.pinnedMessage = msg;
        this.pinningInProgress = false;
      },
      error: (err: unknown) => {
        console.error('[Pin] pinMessage failed', err);
        this.pinningInProgress = false;
      }
    });
  }

  /**
   * Unpin the currently pinned message.
   * Calls DELETE /web/room-manager/rooms/{roomId}/pin/{messageId}.
   */
  handleUnpinMessage(): void {
    if (!this.selectedRoom || !this.pinnedMessage || this.pinningInProgress) return;
    this.pinningInProgress = true;
    const messageIdToUnpin = this.pinnedMessage.messageId;
    this.roomService.unpinMessage(this.selectedRoom.roomId, messageIdToUnpin).subscribe({
      next: () => {
        this.selectedRoom = { ...this.selectedRoom!, pinnedMessageId: null };
        this.pinnedMessage = null;
        this.pinningInProgress = false;
      },
      error: (err: unknown) => {
        console.error('[Pin] unpinMessage failed', err);
        this.pinningInProgress = false;
      }
    });
  }

  // ─────────────────────────────────────────────────────────────────────────

  loadRoomMembers(): void {


// ─── HUNK 5: selectRoom() — resolve pinnedMessage when switching rooms ────
//
// Inside selectRoom() (or whichever method loads messages for a room),
// after `this.messages = messages;` (the next: callback of loadMessages),
// add the following block to resolve the pinned message from the loaded list:
//
// ← FIND (inside loadMessages next callback, around where messages are assigned):
//
//         this.messages = messages;   // or however messages are set
//
// ← AFTER THAT LINE add:
//
        // ─── GAP 10: resolve pinned message ──────────────────────────────
        const pid = this.selectedRoom?.pinnedMessageId;
        if (pid) {
          this.pinnedMessage = this.messages.find(m => m.messageId === pid) ?? null;
        } else {
          this.pinnedMessage = null;
        }
        // ─────────────────────────────────────────────────────────────────
//
// Also clear pinnedMessage when switching rooms. In selectRoom(), where you
// reset state (e.g. `this.messages = []; this.typingUsers = [];`), add:
//
        this.pinnedMessage = null;
        this.pinningInProgress = false;


// ═══════════════════════════════════════════════════════════════════════════
// END OF PATCH
// ═══════════════════════════════════════════════════════════════════════════
