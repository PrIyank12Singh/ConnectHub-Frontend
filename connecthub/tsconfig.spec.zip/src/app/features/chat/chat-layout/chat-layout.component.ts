import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ChatPageComponent } from '../pages/chat-page.component';

@Component({
  selector: 'app-chat-layout',
  standalone: true,
  imports: [ChatPageComponent],
  template: `<app-chat-page />`
})
export class ChatLayoutComponent {}